import express from 'express';
import { Router } from 'express';
import taquillerosRouter from "./taquillerosRouter.js";
import peliculasRouter from "./peliculaRoutes.js";
import salaRouter from "./salaRoutes.js";
import filaRouter from "./filaRouter.js";
import clienteRouter from "./clienteRouter.js";
import boletaRouter from "./boletaRouter.js";
import asientoRouter from "./asientoRouter.js";


function routerApi(app){
  const router = Router();
  app.use('/api/v1', router);
  router.use('/taquilleros', taquillerosRouter);
  router.use('/peliculas', peliculasRouter);
  router.use('/sala', salaRouter);
  router.use('/fila', filaRouter);
  router.use('/cliente', clienteRouter);
  router.use('/boleta', boletaRouter);
  router.use('/asiento', asientoRouter);
}

export default routerApi;
