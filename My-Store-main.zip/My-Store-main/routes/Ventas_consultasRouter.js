// ventasConsultasRoutes.js
import express from 'express';
import { getAllVentasConsultas, getVentasConsultasByFecha,
   getVentasConsultasByPelicula, getVentasConsultasByCliente,
   createVenta } from '../controllers/ventasYconsultasControllers.js';

const router = express.Router();

router.get('/', getAllVentasConsultas);
router.get('/fecha/:fecha', getVentasConsultasByFecha);
router.get('/pelicula/:id_pelicula', getVentasConsultasByPelicula);
router.get('/cliente/:id_cliente', getVentasConsultasByCliente);
router.post('/', createVenta);

export default router;
