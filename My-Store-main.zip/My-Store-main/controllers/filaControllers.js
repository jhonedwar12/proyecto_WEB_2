import pkg from 'pg';
const { Pool } = pkg;

const pool=new Pool ({
  host: 'localhost',
  user:'postgres',
  password:'1',
  database:'proyecto_web2',
  port:'5432'
})


export async function getFilas(req, res) {
  const response = await pool.query('SELECT * FROM Fila');
  res.json(response.rows);
}

export async function postFila(req, res) {
  try {
    const { Id_Fila, Id_Sala, Numero_Fila } = req.body;
    const response = await pool.query('INSERT INTO Fila VALUES($1, $2, $3)', [Id_Fila, Id_Sala, Numero_Fila]);
    res.json({
      message: 'Fila agregada correctamente',
      body: {
        fila: { Id_Fila, Id_Sala, Numero_Fila }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al agregar fila' });
  }finally {
    await pool.end();
  }
}

export async function deleteFila(req, res) {
  try {
    const id = req.params.id;
    const response = await pool.query('DELETE FROM Fila WHERE Id_Fila = $1', [id]);
    res.json({
      message: 'Fila eliminada correctamente',
      body: {
        id,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al eliminar fila' });
  }finally {
    await pool.end();
  }
}

export async function updateFila(req, res) {
  try {
    const { Id_Fila, Id_Sala, Numero_Fila } = req.body;
    const response = await pool.query('UPDATE Fila SET Id_Sala = $1, Numero_Fila = $2 WHERE Id_Fila = $3', [Id_Sala, Numero_Fila, Id_Fila]);
    res.json({
      message: 'Fila actualizada correctamente',
      body: {
        fila: { Id_Fila, Id_Sala, Numero_Fila },
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al actualizar fila' });
  }finally {
    await pool.end();
  }
}

export default { getFilas, postFila, deleteFila, updateFila };
