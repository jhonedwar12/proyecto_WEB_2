import pkg from 'pg';
const { Pool } = pkg;

const pool=new Pool ({
  host: 'localhost',
  user:'postgres',
  password:'1',
  database:'proyecto_web2',
  port:'5432'
})

export async function get(req, res) {
  const response = await pool.query('SELECT* FROM pelicula');
  res.json(response.rows);
}

export async function post(req, res) {
  try {
    const {Id_Pelicula , Titulo , Duracion , Genero , Sinopsis  } = req.body;
    const response = await pool.query('INSERT INTO pelicula  VALUES($1,$2,$3,$4,$5)', [Id_Pelicula , Titulo , Duracion , Genero , Sinopsis ]);
    res.json({
      message: 'Se agrego un usuario',
      body: {
        user: { nombre, apellido }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al agregar usuario' });
  }finally {
    await pool.end();
  }
};

export async function deletePelicula(req, res) {
  try {
    const id = req.params.id;
    const response = await pool.query('DELETE FROM pelicula WHERE id = $1', [id]);
    res.json({
      message: 'Taquillero deleted successfully',
      body: {
        id,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error deleting taquillero' });
  }finally {
    await pool.end();
  }
}

export async function updatePelicula(req, res) {
  try {
    const {   Id_Pelicula , Titulo , Duracion , Genero , Sinopsis  } = req.body;
    const response = await pool.query('UPDATE taquilleros SET Titulo=$1 , Duracion=$2 , Genero=$3 , Sinopsis=$4 WHERE id = $5', [ Titulo , Duracion , Genero , Sinopsis,Id_Pelicula]);
    res.json({
      message: 'Taquillero updated successfully',
      body: {
        user: { id, nombre, apellido },
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating taquillero' });
  }finally {
    await pool.end();
  }
}

export default { deletePelicula, updatePelicula, get, post };
