import pkg from 'pg';
const { Pool } = pkg;

const pool=new Pool ({
  host: 'localhost',
  user:'postgres',
  password:'1',
  database:'proyecto_web2',
  port:'5432'
})

export async function get(req, res) {
  const response = await pool.query('SELECT* FROM taquilleros');
  res.json(response.rows);
}

export async function post(req, res) {
  try {
    const { nombre, apellido } = req.body;
    const response = await pool.query('INSERT INTO taquilleros (nombre, apellido) VALUES($1,$2)', [nombre, apellido]);
    res.json({
      message: 'Se agrego un usuario',
      body: {
        user: { nombre, apellido }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al agregar usuario' });
  }finally {
    await pool.end();
  }
};

export async function deleteTaquillero(req, res) {
  try {
    const id = req.params.id;
    const response = await pool.query('DELETE FROM taquilleros WHERE id = $1', [id]);
    res.json({
      message: 'Taquillero deleted successfully',
      body: {
        id,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error deleting taquillero' });
  }finally {
    await pool.end();
  }
}

export async function updateTaquillero(req, res) {
  try {
    const { nombre, apellido,id } = req.body;
    const response = await pool.query('UPDATE taquilleros SET nombre = $1, apellido = $2 WHERE id = $3', [nombre, apellido, id]);
    res.json({
      message: 'Taquillero updated successfully',
      body: {
        user: { id, nombre, apellido },
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating taquillero' });
  }finally {
    await pool.end();
  }
}

export default { deleteTaquillero, updateTaquillero, get, post };
