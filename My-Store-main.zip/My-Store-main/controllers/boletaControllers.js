import pkg from 'pg';
const { Pool } = pkg;

const pool=new Pool ({
  host: 'localhost',
  user:'postgres',
  password:'1',
  database:'proyecto_web2',
  port:'5432'
})

export async function getBoletas(req, res) {
  const response = await pool.query('SELECT * FROM Boleta');
  res.json(response.rows);
}

export async function postBoleta(req, res) {
  try {
    const { Id_Boleta, Id_Pelicula, Id_Asiento, Id_Taquillero, Id_Cliente, Fecha_Compra, Hora_Compra } = req.body;
    const response = await pool.query('INSERT INTO Boleta VALUES($1, $2, $3, $4, $5, $6, $7)', [Id_Boleta, Id_Pelicula, Id_Asiento, Id_Taquillero, Id_Cliente, Fecha_Compra, Hora_Compra]);
    res.json({
      message: 'Boleta agregada correctamente',
      body: {
        boleta: { Id_Boleta, Id_Pelicula, Id_Asiento, Id_Taquillero, Id_Cliente, Fecha_Compra, Hora_Compra }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al agregar boleta' });
  }finally {
    await pool.end();
  }
}

export async function deleteBoleta(req, res) {
  try {
    const id = req.params.id;
    const response = await pool.query('DELETE FROM Boleta WHERE Id_Boleta = $1', [id]);
    res.json({
      message: 'Boleta eliminada correctamente',
      body: {
        id,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al eliminar boleta' });
  }finally {
    await pool.end();
  }
}

export async function updateBoleta(req, res) {
  try {
    const { Id_Boleta, Id_Pelicula, Id_Asiento, Id_Taquillero, Id_Cliente, Fecha_Compra, Hora_Compra } = req.body;
    const response = await pool.query('UPDATE Boleta SET Id_Pelicula = $1, Id_Asiento = $2, Id_Taquillero = $3, Id_Cliente = $4, Fecha_Compra = $5, Hora_Compra = $6 WHERE Id_Boleta = $7', [Id_Pelicula, Id_Asiento, Id_Taquillero, Id_Cliente, Fecha_Compra, Hora_Compra, Id_Boleta]);
    res.json({
      message: 'Boleta actualizada correctamente',
      body: {
        boleta: { Id_Boleta, Id_Pelicula, Id_Asiento, Id_Taquillero, Id_Cliente, Fecha_Compra, Hora_Compra },
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al actualizar boleta' });
  }finally {
    await pool.end();
  }
}

export default { getBoletas, postBoleta, deleteBoleta, updateBoleta };
