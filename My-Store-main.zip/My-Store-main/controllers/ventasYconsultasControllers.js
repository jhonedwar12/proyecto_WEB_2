// ventasConsultasControllers.js
import { Pool } from 'pg';

const pool = new Pool({
  host: 'localhost',
  user: 'postgres',
  password: '1',
  database: 'proyecto_web2',
  port: '5432'
});

async function getAllVentasConsultas() {
  const result = await pool.query('SELECT * FROM ventas_consultas');
  return result.rows;
}

async function getVentasConsultasByFecha(fecha) {
  const result = await pool.query(`SELECT * FROM ventas_consultas WHERE fecha_venta = '${fecha}'`);
  return result.rows;
}

async function getVentasConsultasByPelicula(idPelicula) {
  const result = await pool.query(`SELECT * FROM ventas_consultas WHERE id_pelicula = ${idPelicula}`);
  return result.rows;
}

async function getVentasConsultasByCliente(idCliente) {
  const result = await pool.query(`SELECT * FROM ventas_consultas WHERE id_cliente = ${idCliente}`);
  return result.rows;
}

async function createVenta(req) {
  const { idPelicula, idAsiento, idCliente, fechaVenta, horaVenta } = req.body;
  const query = {
    text: `INSERT INTO ventas (id_pelicula, id_asiento, id_cliente, fecha_venta, hora_venta) VALUES ($1, $2, $3, $4, $5)`,
    values: [idPelicula, idAsiento, idCliente, fechaVenta, horaVenta]
  };
  const result = await pool.query(query);
  return { message: 'Venta creada con éxito' };
}

export {
  getAllVentasConsultas,
  getVentasConsultasByFecha,
  getVentasConsultasByPelicula,
  getVentasConsultasByCliente,
  createVenta
};
