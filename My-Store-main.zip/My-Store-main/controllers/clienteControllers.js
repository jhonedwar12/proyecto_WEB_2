import pkg from 'pg';
const { Pool } = pkg;

const pool=new Pool ({
  host: 'localhost',
  user:'postgres',
  password:'1',
  database:'proyecto_web2',
  port:'5432'
})

export async function getClientes(req, res) {
  const response = await pool.query('SELECT * FROM Cliente');
  res.json(response.rows);
}

export async function postCliente(req, res) {
  try {
    const { Id_Cliente, Nombre, Apellido } = req.body;
    const response = await pool.query('INSERT INTO Cliente VALUES($1, $2, $3)', [Id_Cliente, Nombre, Apellido]);
    res.json({
      message: 'Cliente agregado correctamente',
      body: {
        cliente: { Id_Cliente, Nombre, Apellido }
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al agregar cliente' });
  }finally {
    await pool.end();
  }
}

export async function deleteCliente(req, res) {
  try {
    const id = req.params.id;
    const response = await pool.query('DELETE FROM Cliente WHERE Id_Cliente = $1', [id]);
    res.json({
      message: 'Cliente eliminado correctamente',
      body: {
        id,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al eliminar cliente' });
  }finally {
    await pool.end();
  }
}

export async function updateCliente(req, res) {
  try {
    const { Id_Cliente, Nombre, Apellido } = req.body;
    const response = await pool.query('UPDATE Cliente SET Nombre = $1, Apellido = $2 WHERE Id_Cliente = $3', [Nombre, Apellido, Id_Cliente]);
    res.json({
      message: 'Cliente actualizado correctamente',
      body: {
        cliente: { Id_Cliente, Nombre, Apellido },
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error al actualizar cliente' });
  }finally {
    await pool.end();
  }
}

export default { getClientes, postCliente, deleteCliente, updateCliente };
