CREATE TABLE Pelicula (
  Id_Pelicula INT PRIMARY KEY,
  Titulo VARCHAR(255) NOT NULL,
  Duracion TIME NOT NULL,
  Genero VARCHAR(50) NOT NULL,
  Sinopsis TEXT NOT NULL
);

CREATE TABLE Sala (
  Id_Sala INT PRIMARY KEY,
  Nombre VARCHAR(100) NOT NULL,
  Capacidad INT NOT NULL
);

CREATE TABLE Fila (
  Id_Fila INT PRIMARY KEY,
  Id_Sala INT NOT NULL,
  Numero_Fila INT NOT NULL,
  FOREIGN KEY (Id_Sala) REFERENCES Sala(Id_Sala) ON DELETE CASCADE
);

CREATE TABLE Asiento (
  Id_Asiento INT PRIMARY KEY,
  Id_Fila INT NOT NULL,
  Numero_Asiento INT NOT NULL,
  FOREIGN KEY (Id_Fila) REFERENCES Fila(Id_Fila) ON DELETE CASCADE
);

CREATE TABLE Taquillero (
  Id_Taquillero INT PRIMARY KEY,
  Nombre VARCHAR(100) NOT NULL,
  Apellido VARCHAR(100) NOT NULL
);

CREATE TABLE Cliente (
  Id_Cliente INT PRIMARY KEY,
  Nombre VARCHAR(100) NOT NULL,
  Apellido VARCHAR(100) NOT NULL
);

CREATE TABLE Boleta (
  Id_Boleta INT PRIMARY KEY,
  Id_Pelicula INT NOT NULL,
  Id_Asiento INT NOT NULL,
  Id_Taquillero INT NOT NULL,
  Id_Cliente INT NOT NULL,
  Fecha_Compra DATE NOT NULL,
  Hora_Compra TIME NOT NULL,
  FOREIGN KEY (Id_Pelicula) REFERENCES Pelicula(Id_Pelicula) ON DELETE CASCADE,
  FOREIGN KEY (Id_Asiento) REFERENCES Asiento(Id_Asiento) ON DELETE CASCADE,
  FOREIGN KEY (Id_Taquillero) REFERENCES Taquillero(Id_Taquillero) ON DELETE CASCADE,
  FOREIGN KEY (Id_Cliente) REFERENCES Cliente(Id_Cliente) ON DELETE CASCADE
);
